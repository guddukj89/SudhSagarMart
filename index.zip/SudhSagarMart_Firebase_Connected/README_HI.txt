SudhSagarMart – Firebase Authentication Connected

Is version me customer authentication Firebase Authentication se connected hai.

Features:
- Create Account (Name, Email, Mobile, Password)
- Real Firebase Email/Password Login
- Logout
- Forgot Password email
- Change Password with current-password verification
- Firebase auth state/session
- Customer profile uses Firebase displayName/email

Firebase project:
sudhsagarmart
Authorized domain already configured:
guddukj89.github.io

IMPORTANT:
Firebase Console -> Authentication -> Sign-in method -> Email/Password -> Enable karke Save karein.

GitHub Pages:
1. index.html ko GitHub repository ke root me upload/replace karein.
2. GitHub Pages enabled rakhein.
3. Website ko HTTPS par open karein.

Note: Orders/cart/wishlist/address/saved-card demo data abhi browser localStorage me hain. Real marketplace ke liye inhe Firestore/backend me migrate karna hoga.
